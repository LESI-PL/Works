﻿//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="Microsoft Corporation">
//     Copyright Microsoft Corporation. All rights reserved.
// </copyright>
// <author> Joao Pedro Marques Figueiredo </author>
// <email> joao.pedro.f93@gmail.com </email>
// <date> 4/4/2020 </date >
// <time> 01:00 </time >
// <version> 0.01 </version>
//-----------------------------------------------------------------------



using System;

namespace Projeto
{
    class Program
    {
        static void Main(string[] args)
        {
            public const int Max = 50;
    }
}
}
