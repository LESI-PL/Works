﻿//-----------------------------------------------------------------------
// <copyright file="Colaboradores.cs" company="Microsoft Corporation">
//     Copyright Microsoft Corporation. All rights reserved.
// </copyright>
// <author> Joao Pedro Marques Figueiredo </author>
// <email> joao.pedro.f93@gmail.com </email>
// <date> 4/4/2020 </date >
// <time> 00:16 </time >
// <version> 0.01 </version>
//-----------------------------------------------------------------------

using System;


namespace Projeto
{
    class Colaboradores
    {

        #region Atributos
        public const int Max = 50;
        Colaborador[] colaboradores;
        int qt_colaboradores;

        #endregion

        #region Constructors

       public Colaboradores(int qt_colaboradores)
        {

        }


        #endregion




    }
}
