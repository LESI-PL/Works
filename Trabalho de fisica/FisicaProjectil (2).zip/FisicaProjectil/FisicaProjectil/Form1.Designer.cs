﻿namespace FisicaProjectil
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblResultV0 = new System.Windows.Forms.Label();
            this.vY = new System.Windows.Forms.Label();
            this.vX = new System.Windows.Forms.Label();
            this.lblTempo = new System.Windows.Forms.Label();
            this.lblResultY = new System.Windows.Forms.Label();
            this.lblResultX = new System.Windows.Forms.Label();
            this.lblResultTime = new System.Windows.Forms.Label();
            this.lblResultAngulo = new System.Windows.Forms.Label();
            this.lblAngulo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLaunch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbVelToatal = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbAlturaMax = new System.Windows.Forms.Label();
            this.lbAlcanceMax = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblResultV0
            // 
            this.lblResultV0.AutoSize = true;
            this.lblResultV0.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultV0.Location = new System.Drawing.Point(118, 11);
            this.lblResultV0.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblResultV0.Name = "lblResultV0";
            this.lblResultV0.Size = new System.Drawing.Size(18, 19);
            this.lblResultV0.TabIndex = 3;
            this.lblResultV0.Text = "0";
            // 
            // vY
            // 
            this.vY.AutoSize = true;
            this.vY.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vY.Location = new System.Drawing.Point(16, 114);
            this.vY.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.vY.Name = "vY";
            this.vY.Size = new System.Drawing.Size(55, 22);
            this.vY.TabIndex = 4;
            this.vY.Text = "Vel. Y";
            // 
            // vX
            // 
            this.vX.AutoSize = true;
            this.vX.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vX.Location = new System.Drawing.Point(16, 80);
            this.vX.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.vX.Name = "vX";
            this.vX.Size = new System.Drawing.Size(56, 22);
            this.vX.TabIndex = 5;
            this.vX.Text = "Vel. X";
            // 
            // lblTempo
            // 
            this.lblTempo.AutoSize = true;
            this.lblTempo.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempo.Location = new System.Drawing.Point(16, 49);
            this.lblTempo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTempo.Name = "lblTempo";
            this.lblTempo.Size = new System.Drawing.Size(50, 22);
            this.lblTempo.TabIndex = 6;
            this.lblTempo.Text = "Time";
            // 
            // lblResultY
            // 
            this.lblResultY.AutoSize = true;
            this.lblResultY.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultY.Location = new System.Drawing.Point(117, 114);
            this.lblResultY.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblResultY.Name = "lblResultY";
            this.lblResultY.Size = new System.Drawing.Size(20, 22);
            this.lblResultY.TabIndex = 7;
            this.lblResultY.Text = "0";
            // 
            // lblResultX
            // 
            this.lblResultX.AutoSize = true;
            this.lblResultX.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultX.Location = new System.Drawing.Point(117, 80);
            this.lblResultX.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblResultX.Name = "lblResultX";
            this.lblResultX.Size = new System.Drawing.Size(20, 22);
            this.lblResultX.TabIndex = 8;
            this.lblResultX.Text = "0";
            // 
            // lblResultTime
            // 
            this.lblResultTime.AutoSize = true;
            this.lblResultTime.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultTime.Location = new System.Drawing.Point(117, 49);
            this.lblResultTime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblResultTime.Name = "lblResultTime";
            this.lblResultTime.Size = new System.Drawing.Size(20, 22);
            this.lblResultTime.TabIndex = 9;
            this.lblResultTime.Text = "0";
            // 
            // lblResultAngulo
            // 
            this.lblResultAngulo.AutoSize = true;
            this.lblResultAngulo.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultAngulo.Location = new System.Drawing.Point(117, 150);
            this.lblResultAngulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblResultAngulo.Name = "lblResultAngulo";
            this.lblResultAngulo.Size = new System.Drawing.Size(20, 22);
            this.lblResultAngulo.TabIndex = 10;
            this.lblResultAngulo.Text = "0";
            // 
            // lblAngulo
            // 
            this.lblAngulo.AutoSize = true;
            this.lblAngulo.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAngulo.Location = new System.Drawing.Point(16, 150);
            this.lblAngulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAngulo.Name = "lblAngulo";
            this.lblAngulo.Size = new System.Drawing.Size(69, 22);
            this.lblAngulo.TabIndex = 11;
            this.lblAngulo.Text = "Ângulo";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbAlcanceMax);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.lbAlturaMax);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lbVelToatal);
            this.panel1.Controls.Add(this.btnLaunch);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblAngulo);
            this.panel1.Controls.Add(this.lblResultV0);
            this.panel1.Controls.Add(this.lblResultAngulo);
            this.panel1.Controls.Add(this.vY);
            this.panel1.Controls.Add(this.lblResultTime);
            this.panel1.Controls.Add(this.vX);
            this.panel1.Controls.Add(this.lblResultX);
            this.panel1.Controls.Add(this.lblTempo);
            this.panel1.Controls.Add(this.lblResultY);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(748, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(280, 596);
            this.panel1.TabIndex = 12;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnLaunch
            // 
            this.btnLaunch.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLaunch.Location = new System.Drawing.Point(20, 312);
            this.btnLaunch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLaunch.Name = "btnLaunch";
            this.btnLaunch.Size = new System.Drawing.Size(240, 84);
            this.btnLaunch.TabIndex = 13;
            this.btnLaunch.Text = "Fire in The Hole!!!";
            this.btnLaunch.UseVisualStyleBackColor = true;
            this.btnLaunch.Click += new System.EventHandler(this.btnLaunch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 22);
            this.label1.TabIndex = 12;
            this.label1.Text = "Vel. Inicial";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 183);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 22);
            this.label2.TabIndex = 15;
            this.label2.Text = "Vel.Total";
            // 
            // lbVelToatal
            // 
            this.lbVelToatal.AutoSize = true;
            this.lbVelToatal.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVelToatal.Location = new System.Drawing.Point(117, 183);
            this.lbVelToatal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbVelToatal.Name = "lbVelToatal";
            this.lbVelToatal.Size = new System.Drawing.Size(20, 22);
            this.lbVelToatal.TabIndex = 14;
            this.lbVelToatal.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 214);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 22);
            this.label3.TabIndex = 17;
            this.label3.Text = "Altura Máxima";
            // 
            // lbAlturaMax
            // 
            this.lbAlturaMax.AutoSize = true;
            this.lbAlturaMax.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlturaMax.Location = new System.Drawing.Point(149, 214);
            this.lbAlturaMax.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbAlturaMax.Name = "lbAlturaMax";
            this.lbAlturaMax.Size = new System.Drawing.Size(20, 22);
            this.lbAlturaMax.TabIndex = 18;
            this.lbAlturaMax.Text = "0";
            // 
            // lbAlcanceMax
            // 
            this.lbAlcanceMax.AutoSize = true;
            this.lbAlcanceMax.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlcanceMax.Location = new System.Drawing.Point(162, 250);
            this.lbAlcanceMax.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbAlcanceMax.Name = "lbAlcanceMax";
            this.lbAlcanceMax.Size = new System.Drawing.Size(20, 22);
            this.lbAlcanceMax.TabIndex = 21;
            this.lbAlcanceMax.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(16, 250);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 22);
            this.label6.TabIndex = 20;
            this.label6.Text = "Alcance Máximo";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(47, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(696, 515);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(136, 183);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(0, 0);
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 596);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblResultV0;
        private System.Windows.Forms.Label vY;
        private System.Windows.Forms.Label vX;
        private System.Windows.Forms.Label lblTempo;
        private System.Windows.Forms.Label lblResultY;
        private System.Windows.Forms.Label lblResultX;
        private System.Windows.Forms.Label lblResultTime;
        private System.Windows.Forms.Label lblResultAngulo;
        private System.Windows.Forms.Label lblAngulo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLaunch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbVelToatal;
        private System.Windows.Forms.Label lbAlturaMax;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbAlcanceMax;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

